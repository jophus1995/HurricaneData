#ifndef HURRICANEDATABASECPP
#define HURRICANEDATABASECPP
#include "HurricaneDataBase.h"
#include <iostream>
#include <fstream>
#include <string>




HurricaneDataBase :: HurricaneDataBase(string filename) {

    ifstream file(filename);

    if(!file.is_open()){

        exit(1);
    }else{
        string temp;
        while(!file.eof()){
            getline(file,temp);
            if(!file.eof()){
                HurricaneEntry hurricane(temp);

                database.InsertInOrder(hurricane);
            }
        }
    }
}

void HurricaneDataBase :: PrintStormsByYear() {
cout << "Prints out the number of storms per year" << endl;
cout << "1 Hurricane = * " << endl;
cout << "1 Tropical Storms = #" << endl;

HurricaneEntry tempHurr;
linked_list<HurricaneEntry> tempDatabase;
database.RemoveFront(tempHurr);
  if(tempHurr.getKey() == 0){
      database.InsertFront(tempHurr);  
      database.PrintAll();
  }else{
      database.InsertInOrder(tempHurr);
     while(!database.IsEmpty()){
       database.RemoveFront(tempHurr);
       tempHurr.setKey(0);
       tempDatabase.InsertInOrder(tempHurr);
     }while(!tempDatabase.IsEmpty()){
        tempDatabase.RemoveFront(tempHurr);
        database.InsertInOrder(tempHurr);
     }
    database.PrintAll();
  }

}


void HurricaneDataBase :: SortsPrintsByNumberofTropicalStorms() {
cout << "Tropical Storms Least to the Most over Time" << endl;

HurricaneEntry tempHurr;
linked_list<HurricaneEntry> tempDatabase;
database.RemoveFront(tempHurr);
  if(tempHurr.getKey() == 2){
      database.InsertFront(tempHurr);  
      database.PrintAll();
  }else{
      database.InsertInOrder(tempHurr);
     while(!database.IsEmpty()){
       database.RemoveFront(tempHurr);
       tempHurr.setKey(2);
       tempDatabase.InsertInOrder(tempHurr);
     }while(!tempDatabase.IsEmpty()){
        tempDatabase.RemoveFront(tempHurr);
        database.InsertInOrder(tempHurr);
     }
    database.PrintAll();
  }

}
void HurricaneDataBase :: SortsPrintsByNumberofHurricanes() {
cout << "Hurricanes Least to the Most over Time" << endl;
HurricaneEntry tempHurr;
linked_list<HurricaneEntry> tempDatabase;
database.RemoveFront(tempHurr);
  if(tempHurr.getKey() == 1){
      database.InsertFront(tempHurr);  
      database.PrintAll();
  }else{
      database.InsertInOrder(tempHurr);
     while(!database.IsEmpty()){
       database.RemoveFront(tempHurr);
       tempHurr.setKey(1);
       tempDatabase.InsertInOrder(tempHurr);
     }while(!tempDatabase.IsEmpty()){
        tempDatabase.RemoveFront(tempHurr);
        database.InsertInOrder(tempHurr);
     }
    database.PrintAll();
  }

}

void HurricaneDataBase :: SortsPrintsByNumberofMajorStorms() {
cout << "Major Storms Least to the Most over Time" << endl;
HurricaneEntry tempHurr;
linked_list<HurricaneEntry> tempDatabase;
database.RemoveFront(tempHurr);
  if(tempHurr.getKey() == 3){
      database.InsertFront(tempHurr);  
      database.PrintAll();
  }else{
      database.InsertInOrder(tempHurr);
     while(!database.IsEmpty()){
       database.RemoveFront(tempHurr);
       tempHurr.setKey(3);
       tempDatabase.InsertInOrder(tempHurr);
     }while(!tempDatabase.IsEmpty()){
        tempDatabase.RemoveFront(tempHurr);
        database.InsertInOrder(tempHurr);
     }
    database.PrintAll();
  }


}

void HurricaneDataBase :: SortsPrintsByNumberofDeaths() {
cout << "Lost of Life Due to Storms Least to the Most over Time" << endl;
HurricaneEntry tempHurr;
linked_list<HurricaneEntry> tempDatabase;
database.RemoveFront(tempHurr);
  if(tempHurr.getKey() == 4){
      database.InsertFront(tempHurr);  
      database.PrintAll();
  }else{
      database.InsertInOrder(tempHurr);
     while(!database.IsEmpty()){
       database.RemoveFront(tempHurr);
       tempHurr.setKey(4);
       tempDatabase.InsertInOrder(tempHurr);
     }while(!tempDatabase.IsEmpty()){
        tempDatabase.RemoveFront(tempHurr);
        database.InsertInOrder(tempHurr);
     }
    database.PrintAll();
  }

}

ostream & operator << (ostream &out, HurricaneEntry temp) {
            string Strong = temp.getStrongestStorms().at(0);
            int numHurr = temp.getnumHurricanes();
            string numH;
            for(int i = 0;i < numHurr; i++){
                numH += "*";
            }
            int numTrop = temp.getnumTropicalStorms();
            string numT;
            for(int i = 0;i<numTrop;i++){
                numT += "#";
            }
            int numMH = temp.getnumMajorHurricanes();
            string numMHurr;
            for(int i = 0;i < numMH;i++){
                numMHurr += "X";
            }
            if(temp.getKey() == 0){
            out << temp.getYear() << "\n" << "Hurricanes-" << numH << "\n" << "Tropical St-" << numT << "\n" << "Largest Storm-" << Strong << endl;
            return out;
            
            }else if(temp.getKey() == 1){
            out << temp.getYear() << "- " << numH << endl;
            return out;            
            
            }else if(temp.getKey() == 2){
            out <<  temp.getYear() << "-" << numT << endl;
            return out;
            
            }else if(temp.getKey() == 3){
            out << temp.getYear() << "-" << numMHurr << endl;
            return out;
            
            }else if(temp.getKey() == 4){
                if(temp.getnumDeaths() == -1){
                    string deaths = "Unknown";
                    out << temp.getYear() << "-" << deaths << endl;
                }else
            out << temp.getYear() << "-" << temp.getnumDeaths() << endl;
            return out;
            }
}
#endif
