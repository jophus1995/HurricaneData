#ifndef HURRICANEENTRYCPP
#define HURRICANEENTRYCPP
#include "HurricaneEntry.h"
#include <vector>
#include <iostream>
#include <string>
#include <fstream>

using namespace std;

HurricaneEntry :: HurricaneEntry() {
    this -> year = 0;
    this -> numTropicalStorms = 0;
    this -> numHurricanes = 0;
    this -> numMajorHurricanes = 0;
    this -> numDeaths = 0;
    vector<string> StrongestStorms;
    this -> key = 0;
}

HurricaneEntry :: HurricaneEntry(string line) {
    //do parsing
    int index;
    key = 0;

    index = line.find(',');
    string temp = line.substr(0,index);
    this -> year = stoi(temp);
    line.erase(line.begin(), line.begin()+index+1);

    index = line.find(',');
    temp = line.substr(0,index);
    this -> numTropicalStorms = stoi(temp);
    line.erase(line.begin(), line.begin()+index+1);

    index = line.find(',');
    temp = line.substr(0,index);
    this -> numHurricanes = stoi(temp);
    line.erase(line.begin(), line.begin()+index+1);

    index = line.find(',');
    temp = line.substr(0,index);
    this -> numMajorHurricanes = stoi(temp);
    line.erase(line.begin(), line.begin()+index+1);

    
    index = line.find(',');
    temp = line.substr(0,index);
    if(temp == "Unknown"){
        numDeaths = -1;
    line.erase(line.begin(),line.begin()+index+1);
    }else{
    this -> numDeaths =  stoi(temp);
    line.erase(line.begin(), line.begin()+index+1);
    } 
    while(index > 0){
    index = line.find('\n');
    int numDash = line.find(" - ");
    temp = line.substr(0,numDash);
    StrongestStorms.push_back(temp);
    line.erase(line.begin(), line.begin()+numDash+1);
    }
}

void HurricaneEntry :: setYear(int newYear) {
    year = newYear;
}

int HurricaneEntry :: getYear() {
    return year;
}

void HurricaneEntry :: setnumTropicalStorms(int newNumTropicalStorms) {
    numTropicalStorms = newNumTropicalStorms;
}

int HurricaneEntry :: getnumTropicalStorms() {
    return numTropicalStorms;
}

void HurricaneEntry :: setnumHurricanes(int newNumHurricanes) {
    numHurricanes = newNumHurricanes;
}

int HurricaneEntry :: getnumHurricanes() {
    return numHurricanes;
}

void HurricaneEntry :: setnumMajorHurricanes(int newNumMajorHurricanes) {
    numMajorHurricanes = newNumMajorHurricanes;
}

int HurricaneEntry :: getnumMajorHurricanes() {
    return numMajorHurricanes;
}

void HurricaneEntry :: setnumDeaths(int newNumDeaths) {
    numDeaths = newNumDeaths;
}

int HurricaneEntry :: getnumDeaths() {
    return numDeaths;
}

vector<string> HurricaneEntry :: getStrongestStorms() {
    return StrongestStorms;

}
int HurricaneEntry :: getNumberStrongestStorms(){
    return StrongestStorms.size();
}
void HurricaneEntry :: setKey(int newKey) {
    key = newKey;
}

int HurricaneEntry :: getKey() {
    return key;
}

bool HurricaneEntry :: operator < (HurricaneEntry left) {
    if(key == 0){
        if(year < left.year){
            return true;
        }else
            return false;
    }
    else if(key == 1){
        if(numHurricanes < left.numHurricanes){
            return true;
        }else
            return false;
    }else if(key == 2){
        if(numTropicalStorms < left.numTropicalStorms){
            return true;
        }else
            return false;
    }else if(key == 3){
        if(numMajorHurricanes < left.numMajorHurricanes){
            return true;
        }else
            return false;
    }else if(key == 4){
        if(numDeaths < left.numDeaths){
            return true;
        }else
            return false;
    }else if(key == 5){
        if(StrongestStorms < left.StrongestStorms){
            return true;
        }else
            return false;
    }
}

bool HurricaneEntry :: operator > (HurricaneEntry left) {
    if(key == 0){
        if(year > left.year){
            return true;
        }else
            return false;
    }
    else if(key == 1){
        if(numHurricanes > left.numHurricanes){
            return true;
        }else
            return false;
    }
    else if(key == 2){
        if(numTropicalStorms > left.numTropicalStorms){
            return true;
        }else
            return false;
    }
    else if(key == 3){
        if(numMajorHurricanes > left.numMajorHurricanes){
            return true;
        }else
            return false;
    }
    else if(key == 4){
        if(numDeaths > left.numDeaths){
            return true;
        }else
            return false;
    }
    else if(key == 5){
        if(StrongestStorms > left.StrongestStorms){
            return true;
        }else
            return false;
    }
}

bool HurricaneEntry :: operator <= (HurricaneEntry left) {
    if(key == 0){
        if(year <= left.year){
            return true;
        }else
            return false;
    }
    else if(key == 1){
        if(numHurricanes <= left.numHurricanes){
            return true;
        }else
            return false;
    }
    else if(key == 2){
        if(numTropicalStorms <= left.numTropicalStorms){
            return true;
        }else
            return false;
    }
    else if(key == 3){
        if(numMajorHurricanes <= left.numMajorHurricanes){
            return true;
        }else
            return false;
    }
    else if(key == 4){
        if(numDeaths <= left.numDeaths){
            return true;
        }else
            return false;
    }
    else if(key == 5){
        if(StrongestStorms <= left.StrongestStorms){
            return true;
        }else
            return false;
    }
}

bool HurricaneEntry :: operator >= (HurricaneEntry left) {
    if(key == 0){
        if(year >= left.year){
            return true;
        }else
            return false;
    }
    else if(key == 1){
        if(numHurricanes >= left.numHurricanes){
            return true;
        }else
            return false;
    }
    else if(key == 2){
        if(numTropicalStorms >= left.numTropicalStorms){
            return true;
        }else
            return false;
    }
    else if(key == 3){
        if(numMajorHurricanes >= left.numMajorHurricanes){
            return true;
        }else
            return false;
    }
    else if(key == 4){
        if(numDeaths >= left.numDeaths){
            return true;
        }else
            return false;
    }
    else if(key == 5){
        if(StrongestStorms >= left.StrongestStorms){
            return true;
        }else
            return false;
    }
}

bool HurricaneEntry :: operator == (HurricaneEntry left) {
    if(key == 0){
        if(year == left.year){
            return true;
        }else
            return false;
    }
    else if(key == 1){
        if(numHurricanes == left.numHurricanes){
            return true;
        }else
            return false;
    }
    else if(key == 2){
        if(numTropicalStorms == left.numTropicalStorms){
            return true;
        }else
            return false;
    }
    else if(key == 3){
        if(numMajorHurricanes == left.numMajorHurricanes){
            return true;
        }else
            return false;
    }
    else if(key == 4){
        if(numDeaths == left.numDeaths){
            return true;
        }else
            return false;
    }
    else if(key == 5){
        if(StrongestStorms == left.StrongestStorms){
            return true;
        }else
            return false;
    }
}

bool HurricaneEntry :: operator != (HurricaneEntry left) {
    if(key == 0){
        if(year != left.year){
            return true;
        }else
            return false;
    }
    else if(key == 1){
        if(numHurricanes != left.numHurricanes){
            return true;
        }else
            return false;
    }
    else if(key == 2){
        if(numTropicalStorms != left.numTropicalStorms){
            return true;
        }else
            return false;
    }
    else if(key == 3){
        if(numMajorHurricanes != left.numMajorHurricanes){
            return true;
        }else
            return false;
    }
    else if(key == 4){
        if(numDeaths != left.numDeaths){
            return true;
        }else
            return false;
    }
    else if(key == 5){
        if(StrongestStorms != left.StrongestStorms){
            return true;
        }else
            return false;
    }
}



#endif
