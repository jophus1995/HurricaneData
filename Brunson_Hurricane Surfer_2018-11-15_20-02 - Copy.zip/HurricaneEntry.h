//
//  HurricaneEntry .h
//  Word Surfer
//
//  Created by Jennifer Polack on 4/4/18.
//  Copyright © 2018 Jennifer Polack. All rights reserved.
//

#ifndef HURRICANEENTRYH
#define HURRICANEENTRYH
#include <vector>
#include <iostream>
#include <string>
using namespace std;

class HurricaneEntry {
    friend ostream & operator<<(ostream &out, HurricaneEntry temp);
public:


    HurricaneEntry();
    HurricaneEntry(string line);
    void setYear(int year);
    int getYear();
    void setnumTropicalStorms(int numTropicalStorms);
    int getnumTropicalStorms();
    void setnumHurricanes(int numHurricanes);
    int getnumHurricanes();
    void setnumMajorHurricanes(int numMajorHurricanes);
    int getnumMajorHurricanes();
    void setnumDeaths(int numDeaths);
    int getnumDeaths();
    vector<string> getStrongestStorms();
    int getNumberStrongestStorms();
    void setKey(int key);
    //Will be one of the constant from above
    //If Hurricane is the key that means the linked list is will be created based year
    int getKey();
    
    bool operator< (HurricaneEntry left);
    bool operator> (HurricaneEntry left);
    bool operator<= (HurricaneEntry left);
    bool operator>= (HurricaneEntry left);
    bool operator!= (HurricaneEntry left);
    bool operator== (HurricaneEntry left);
    
private:
    
    int year;
    int numTropicalStorms;
    int numHurricanes;
    int numMajorHurricanes;
    int numDeaths;
    vector<string>    StrongestStorms;
    int key;

    
};


#endif /* HurricaneEntry__h */
