//
//  HurricaneDataBase .h
//  Word Surfer
//
//  Created by Jennifer Polack on 4/4/18.
//  Copyright © 2018 Jennifer Polack. All rights reserved.
//

#ifndef HurricaneDataBase__h
#define HurricaneDataBase__h
#include <iostream>
#include <fstream>
#include <string>

#include "HurricaneEntry.h"
#include "linked_list.h"
using namespace std;

class HurricaneDataBase {
public:
    const int YEAR=0; //Used to compare or print out Year Informatiuon
    const int HURRICANE= 1; //Used to compare or print out hurricane information
    const int STORM = 2;  //Used to compare or print out tropical storms
    const int MAJOR = 3; //Used to compare or print out Major Storms
    const int DEATHS = 4;   //Used to compare or print out deaths based on year
    const int STRONGEST = 5; //Used to compare or print out Strongest Storms
    HurricaneDataBase();    
    HurricaneDataBase(string filename);
    void PrintStormsByYear();
    void SortsPrintsByNumberofTropicalStorms();
    void SortsPrintsByNumberofHurricanes();
    void SortsPrintsByNumberofMajorStorms();
    void SortsPrintsByNumberofDeaths();
private:
    linked_list<HurricaneEntry> database;
};


#endif /* HurricaneDataBase__h */
