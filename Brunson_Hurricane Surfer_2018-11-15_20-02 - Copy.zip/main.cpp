#include "HurricaneDataBase.h"
#include "HurricaneEntry.h"
#include "linked_list.h"
#include <iostream>
#include <string>

int main() {

    HurricaneDataBase database("HurricaneData.csv");


int choice = 0;

while (choice != 6) {
    cout << "1:Print Yearly Hurricane Data." << endl;
    cout << "2:Print out Tropical Storms in order from least to most" << endl;
    cout << "3:Print out Hurricanes in order from least to most" << endl;
    cout << "4:Print out Major Hurricanes in order from least to most" << endl;
    cout << "5:Print out Number of Deaths in order from least to most" << endl;
    cout << "6:Exit" << endl;
    cout << "Enter a choice:";
    cin >> choice;
    cout << endl;

if(choice == 1) {

    database.PrintStormsByYear();

}else if(choice == 2){

    database.SortsPrintsByNumberofTropicalStorms();

}else if(choice == 3){
    database.SortsPrintsByNumberofHurricanes();

}else if(choice == 4){
    database.SortsPrintsByNumberofMajorStorms();

}else if(choice == 5){
    database.SortsPrintsByNumberofDeaths();

}else if(choice == 6){
    break;

    }
}
return 0;


}



