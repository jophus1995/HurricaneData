#ifndef LIST_CPP
#define LIST_CPP
#include "linked_list.h"
#include "single_node.h"
#include <iostream>
#include <string>
using namespace std;

/*template <class NODETYPE>
linked_list<NODETYPE>:: linked_list<NODETYPE> &operator=(const linked_list<NODETYPE> &origList) {
linked_list<NODETYPE> temp = NULL;

LISTNODE<NODETYPE> tempNode;

current = first;
while(current!= nullptr){
origList.RemoveFront(tempNode);

temp.InsertFront(tempNode);

current = current -> next;
}

}
*/

template <class NODETYPE>
linked_list<NODETYPE>::linked_list() {
    first = NULL;
    current = NULL;
    last = NULL;
}

template <class NODETYPE>
linked_list<NODETYPE>::~linked_list() {
    current = first;
    while (current != NULL) {
        first = first->next;
        delete current;
        current = first;
    }
    current = last = first = NULL;
}
template <class NODETYPE>
linked_list<NODETYPE>::linked_list(linked_list<NODETYPE> &originalList) {
    if(originalList.first == nullptr){
        first == nullptr;
        last == nullptr;
    }else{
        ListNode<NODETYPE> *orig, *lastptr;
        orig = originalList.first;
        lastptr = new ListNode<NODETYPE>;
        if(lastptr != nullptr){
            lastptr -> data = orig -> data;
            first = lastptr;
            current = first;
            orig = orig -> next;
            while(orig != nullptr) {
                current = lastptr;
                lastptr = new ListNode<NODETYPE>(orig -> data);
                if(lastptr != nullptr){
                    current -> next = lastptr;
                }
                orig = orig -> next;
            }
            last = lastptr;
        }
    }
}
template <class NODETYPE>
bool linked_list<NODETYPE>::InsertInOrder(NODETYPE value){
    if(IsEmpty()) {
        InsertFront(value);
    }else if(value >= last -> data){ 
        InsertRear(value);
    }else if(first -> data >= value){ 
        InsertFront(value);
    }else{
        ListNode<NODETYPE> *temp = nullptr;
        temp = new ListNode<NODETYPE>;
        if(temp != nullptr){
            temp -> data = value;
        }
        current = first;
        while(current -> next != nullptr && value >= current -> next -> data){
            current = current -> next;
        }
        if(current -> next != nullptr){
            temp -> next = current -> next;
            current -> next = temp;
            return true;
    }
    }
}
template <class NODETYPE>
bool linked_list<NODETYPE>::InsertFront(NODETYPE value) {

    if(first==NULL){
        first = new ListNode<NODETYPE>;
        if(first != NULL) {
            first -> data = value;
            first -> next = NULL;
            last = first;
            return true;
        }
        }else{
            current = NULL;
            current = new ListNode<NODETYPE>;
            if(current != NULL){
                current -> data = value;
                current -> next = first;
                first = current;
                return true;
            }else{
                return false;
            }
    }
}
template <class NODETYPE>
bool linked_list<NODETYPE>::InsertRear(NODETYPE value) { 

    if(first==NULL){
        first = new ListNode<NODETYPE>;
        if(first != NULL){ 
            first -> data = value;
            first -> next = NULL;
            last = first;
        }
    }else{
            current = NULL;
            current = new ListNode<NODETYPE>;
            if(current != NULL){
                current->data = value;
                current->next = NULL;
                last->next = current;
                last = current;
                last -> next = nullptr;
                return true;
            }else{
                return false;
            }
        }
    }
template <class NODETYPE>
bool linked_list<NODETYPE>::IsEmpty() const {
    return (first == NULL);
}

template <class NODETYPE>
bool linked_list<NODETYPE>::Search(NODETYPE value) {
    if(first == NULL && last == first){
        return false;
    }
    current = first;
    while(current != NULL && current -> data != value) {
        current = current -> next;
    }    
    if(current == NULL) {
        return false;
    }else{
        return true;
    } 
}


template <class NODETYPE>
void linked_list<NODETYPE>::PrintAll() {
    current = first;
    while(current != nullptr){
        cout << current -> data << endl;
        current = current -> next;
    }
}
template <class NODETYPE>
bool linked_list<NODETYPE>::RemoveFront(NODETYPE & value) {
    if(first == nullptr){
        return false;
    }
    else if(first == last ){
        value = first -> data;
        delete first;
        first = last = current = nullptr;
        //cout<<"It is now empty";
        return true;
    }
    else {
       // cout<<"First Node\n";
        value = first -> data;
        current = first -> next;
        delete first;
        first = current;
    } 
    return true;
}

/*template <class NODETYPE>
bool linked_list<NODETYPE>::RemoveFront(NODETYPE & value) {
    if(first == nullptr){
        return false;
    }
    else if(first == last && first -> data == value){
        value = first -> data;
        delete first;
        first = last = current = nullptr;
        return true;
    }
    else if(first -> data == value){
        value = first -> data;
        current = first -> next;
        delete first;
        first = current;
    } 
    return true;
}*/
template <class NODETYPE>
bool linked_list<NODETYPE>::RemoveRear(NODETYPE & value) {
    current = first;
    while(current != nullptr && current -> next -> data != value){
        current = current -> next;
    }
    if(last -> data == value){
        value = last -> data;
        delete last;
        last = current;
        last -> next = nullptr;
    }
return true;

}
template <class NODETYPE>
bool linked_list<NODETYPE>::Remove(NODETYPE & value) {
    if(first == nullptr){
        return false;
    }
    else if(first == last && first -> data == value){
        value = first -> data;
        delete first;
        first = last = current = nullptr;
        return true;
    }
    else if(first -> data == value){
        value = first -> data;
        current = first -> next;
        delete first;
        first = current;
        return true;
    }else if(last -> data == value){
            RemoveRear(value);
            return true;
        }
    else {
        current = first;
        while(current->next != nullptr){ 
            if (current -> next -> data == value)
                break;
            current = current -> next;
        }
        if (current->next!=nullptr){  
            ListNode<NODETYPE> *temp;
            temp = current -> next;
            value = temp -> data;
            current -> next = current -> next -> next;
            delete temp;
            return true;
        }    
        return false;
    }
}

#endif
